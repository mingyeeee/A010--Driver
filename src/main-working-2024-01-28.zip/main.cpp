#include <Arduino.h>

#define TOF_SERIAL Serial1

// Define constants for frame head and tail
#define FRAME_HEAD_1 0x00
#define FRAME_HEAD_2 0xFF
#define FRAME_TAIL 0xDD

uint8_t rawData[4096*3]; // Assuming the maximum data length
//uint8_t frameData[4096]; // Assuming the maximum data length

void setup() {
  Serial.begin(921600);
  Serial.println("Starting");
  //TOF_SERIAL.begin(115200);
  //TOF_SERIAL.write("AT+BAUD=5\r");
  //TOF_SERIAL.end();
  TOF_SERIAL.begin(921600);
  TOF_SERIAL.write("AT+DISP=5\r");
  TOF_SERIAL.write("AT+FPS=10\r");
}
int idx;
    uint16_t dataLen, frameLen, frameDataLen;
    uint8_t frameTail, _sum;
    uint16_t frameID;
    uint8_t resR, resC;

    uint8_t head1flag = 0;

void getSerialBytes(uint8_t* data, uint16_t len)
{
  uint16_t counter=0;

  while(counter < len)
  {
    if(TOF_SERIAL.available())
    {
      data[counter]= TOF_SERIAL.read();
      counter++;
    }
  }
}
void loop() {

/*
    while (TOF_SERIAL.available()) 
    {
      int data = TOF_SERIAL.read();
      Serial.print(data,HEX);
        
        
    }
*/
    // Read data from UART
    if (TOF_SERIAL.available()) 
    {
        rawData[0] = TOF_SERIAL.read();
        //Serial.println("new data");
        //Serial.print(rawData[0],HEX);
        //Serial.print(" ");

        // Find frame head
        if (rawData[0] == FRAME_HEAD_1) 
        {
          //Serial.println("point 1");
          getSerialBytes(&rawData[1], 1);
          //Serial.println("point 2");
          if(rawData[1] == FRAME_HEAD_2)
          {
            //Serial.println("HEAD FOUND");
            getSerialBytes(&rawData[2], 2);

            dataLen = (rawData[2]) | (rawData[3] << 8);
            //Serial.print("data len: ");
            //Serial.println(dataLen);

            getSerialBytes(&rawData[4], dataLen);
            
            Serial.print("SAMPLE: ");
            Serial.println(rawData[5000]); 
            // The data is exponentially scaled so values futher away are less accurate than values closer to the sensor. changing the UNIT from 0 to another number (1-9), linear scale, less range
            Serial.println((rawData[5000]/5.1)*(rawData[5000]/5.1));

            uint8_t endbytes[2];
            getSerialBytes(&endbytes[0], 2);

            //Serial.print("checksum: "); 
            //Serial.println(endbytes[0]);
            //Serial.print("eot: ");
            //Serial.println(endbytes[1],HEX);
            
          }
          
        }
    }
    
}

